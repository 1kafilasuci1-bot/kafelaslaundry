/**
 * Copyright 2018 Google Inc. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *     http://www.apache.org/licenses/LICENSE-2.0
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

// If the loader is already loaded, just stop.
if (!self.define) {
  let registry = {};

  // Used for `eval` and `importScripts` where we can't get script URL by other means.
  // In both cases, it's safe to use a global var because those functions are synchronous.
  let nextDefineUri;

  const singleRequire = (uri, parentUri) => {
    uri = new URL(uri + ".js", parentUri).href;
    return registry[uri] || (
      
        new Promise(resolve => {
          if ("document" in self) {
            const script = document.createElement("script");
            script.src = uri;
            script.onload = resolve;
            document.head.appendChild(script);
          } else {
            nextDefineUri = uri;
            importScripts(uri);
            resolve();
          }
        })
      
      .then(() => {
        let promise = registry[uri];
        if (!promise) {
          throw new Error(`Module ${uri} didn’t register its module`);
        }
        return promise;
      })
    );
  };

  self.define = (depsNames, factory) => {
    const uri = nextDefineUri || ("document" in self ? document.currentScript.src : "") || location.href;
    if (registry[uri]) {
      // Module is already loading or loaded.
      return;
    }
    let exports = {};
    const require = depUri => singleRequire(depUri, uri);
    const specialDeps = {
      module: { uri },
      exports,
      require
    };
    registry[uri] = Promise.all(depsNames.map(
      depName => specialDeps[depName] || require(depName)
    )).then(deps => {
      factory(...deps);
      return exports;
    });
  };
}
define(['./workbox-7e5eb42b'], (function (workbox) { 'use strict';

  self.skipWaiting();
  workbox.clientsClaim();
  /**
   * The precacheAndRoute() method efficiently caches and responds to
   * requests for URLs in the manifest.
   * See https://goo.gl/S9QRab
   */
  workbox.precacheAndRoute([{
    "url": "pwa-maskable-512x512.png",
    "revision": "d50e8a7d9d4c7c3d43dc6201ef773582"
  }, {
    "url": "pwa-512x512.png",
    "revision": "d50e8a7d9d4c7c3d43dc6201ef773582"
  }, {
    "url": "pwa-192x192.png",
    "revision": "a4f0b906c4a2fa9b7be9ad93ae8d2d4c"
  }, {
    "url": "profil.html",
    "revision": "df9c0990c522a6c47b77ac5a2e7e3472"
  }, {
    "url": "logo-kafela.svg",
    "revision": "1381d9a77bf48e387edeb0a9b9899e0d"
  }, {
    "url": "logo-kafela.png",
    "revision": "d50e8a7d9d4c7c3d43dc6201ef773582"
  }, {
    "url": "index.html",
    "revision": "dc293f380e88bc7be4f64a2cd4871b37"
  }, {
    "url": "icon.svg",
    "revision": "1381d9a77bf48e387edeb0a9b9899e0d"
  }, {
    "url": "firebase-config.js",
    "revision": "2c3ceb88863ffe1e983dfdc02886f874"
  }, {
    "url": "favicon.svg",
    "revision": "1381d9a77bf48e387edeb0a9b9899e0d"
  }, {
    "url": "favicon.ico",
    "revision": "a4f0b906c4a2fa9b7be9ad93ae8d2d4c"
  }, {
    "url": "booking.html",
    "revision": "3f493f16c94292e5cf0d128c7d2767c7"
  }, {
    "url": "apple-touch-icon.png",
    "revision": "2c2dd1a1924c57b15795ffa314ca6bcf"
  }, {
    "url": "assets/workbox-window.prod.es5-Bd17z0YL.js",
    "revision": null
  }, {
    "url": "assets/index-LEffQDt4.js",
    "revision": null
  }, {
    "url": "assets/index-CpaC_dQ-.css",
    "revision": null
  }, {
    "url": "apple-touch-icon.png",
    "revision": "2c2dd1a1924c57b15795ffa314ca6bcf"
  }, {
    "url": "favicon.ico",
    "revision": "a4f0b906c4a2fa9b7be9ad93ae8d2d4c"
  }, {
    "url": "icon.svg",
    "revision": "1381d9a77bf48e387edeb0a9b9899e0d"
  }, {
    "url": "pwa-192x192.png",
    "revision": "a4f0b906c4a2fa9b7be9ad93ae8d2d4c"
  }, {
    "url": "pwa-512x512.png",
    "revision": "d50e8a7d9d4c7c3d43dc6201ef773582"
  }, {
    "url": "pwa-maskable-512x512.png",
    "revision": "d50e8a7d9d4c7c3d43dc6201ef773582"
  }, {
    "url": "manifest.webmanifest",
    "revision": "2c3a4f65f2f856757669840a5f30b6e4"
  }], {});
  workbox.cleanupOutdatedCaches();
  workbox.registerRoute(new workbox.NavigationRoute(workbox.createHandlerBoundToURL("index.html")));

}));
